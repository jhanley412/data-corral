SITES = {
    'Boot Barn' : 34202547
    ,'Sheplers' : 4334993
    ,'Country Outfitter' : 42378770
    ,'Idyllwind' : 174262201
    ,'Shyanne' : 171114696
    ,'Cody James' : 171120317
    ,'El Dorado' : 174274627
    ,'Hawx' : 182743748
    ,'Moonshine' : 171092417
    ,'Wonderwest' : 177857880
    ,'Commercial' : 189515404
}
